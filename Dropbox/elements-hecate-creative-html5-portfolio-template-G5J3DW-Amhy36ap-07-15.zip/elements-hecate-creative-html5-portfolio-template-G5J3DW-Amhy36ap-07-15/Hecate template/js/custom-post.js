(function($) { "use strict";


	//Tooltip

	$(document).ready(function() {
		$(".tipped").tipper();
	});	
		 


	
  })(jQuery); 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 





	